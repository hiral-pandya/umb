package edu.umb.cs680.hw13;

public class DJIAEvent {
    private Float djia;

    DJIAEvent(Float d) {
        djia = d;
    }

    public float getDjia() {
        return djia;
    }
}
