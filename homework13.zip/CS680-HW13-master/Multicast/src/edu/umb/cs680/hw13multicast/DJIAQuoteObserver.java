package edu.umb.cs680.hw13multicast;

public interface DJIAQuoteObserver {
    void updateDJIA(DJIAEvent e);
}
