package edu.umb.cs680.hw13multicast;

public class DJIAEvent {
    private Float djia;

    DJIAEvent(Float q) {
        djia = q;
    }

    public float getDjia() {
        return djia;
    }
}
